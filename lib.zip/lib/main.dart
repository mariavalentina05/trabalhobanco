// main.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'dao/dogdao.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'model/dogmodel.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isWindows || Platform.isLinux) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  }

  // Exemplo de dado inicial (remova se não quiser duplicar)
  await insertDog(Dog(id: 1, nome: 'AuAu', idade: 11));

  runApp(const MaterialApp(home: TelaInicial()));
}

// ---------- TELA PRINCIPAL ----------
class TelaInicial extends StatefulWidget {
  const TelaInicial({super.key});

  @override
  State<TelaInicial> createState() => _TelaInicialState();
}

class _TelaInicialState extends State<TelaInicial> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            const Text('Lista de Auaus', style: TextStyle(color: Colors.white)),
        backgroundColor: const Color.fromARGB(255, 11, 151, 185),
      ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color.fromARGB(255, 11, 151, 185),
        child: const Icon(Icons.add),
        onPressed: () async {
          // Aguarda o form terminar e, ao voltar, faz setState para recarregar.
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const DogFormScreen()),
          );
          setState(() {}); // força rebuild → FutureBuilder chama findAll()
        },
      ),

      body: FutureBuilder(
        initialData: const [],
        future: findAll(),
        builder: (context, snapshot) {
          switch (snapshot.connectionState) {
            case ConnectionState.waiting:
            case ConnectionState.active:
              return const Center(child: CircularProgressIndicator());

            case ConnectionState.none:
              return const Center(child: Text('Erro de conexão'));

            case ConnectionState.done:
              final List<Map<String, dynamic>> dogs =
                  snapshot.data as List<Map<String, dynamic>>;
              if (dogs.isEmpty) {
                return const Center(child: Text('Nenhum cachorro cadastrado'));
              }
              return ListView.builder(
                itemCount: dogs.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(dogs[index]['nome']),
                    subtitle: Text(dogs[index]['idade'].toString()),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () async {
                        await deleteById(dogs[index]['id']);
                        setState(() {});
                      },
                    ),
                  );
                },
              );
          }
        },
      ),
    );
  }
}

// ---------- TELA DE CADASTRO ----------
class DogFormScreen extends StatefulWidget {
  const DogFormScreen({super.key});

  @override
  State<DogFormScreen> createState() => _DogFormScreenState();
}

class _DogFormScreenState extends State<DogFormScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _ageController.dispose();
    super.dispose();
  }

  Future<void> _saveDog() async {
    final nome = _nameController.text.trim();
    final idadeStr = _ageController.text.trim();

    if (nome.isEmpty || idadeStr.isEmpty) return;

    final idade = int.tryParse(idadeStr);
    if (idade == null) return; // idade inválida

    final dog = Dog(
      id: DateTime.now().millisecondsSinceEpoch, // id único simples
      nome: nome,
      idade: idade,
    );
    await insertDog(dog);
    Navigator.pop(context); // volta para a tela inicial
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            const Text('Novo Cachorro', style: TextStyle(color: Colors.white)),
        backgroundColor: const Color.fromARGB(255, 11, 151, 185),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration:
                  const InputDecoration(labelText: 'Nome do Cachorro'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _ageController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Idade'),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saveDog,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color.fromARGB(255, 11, 151, 185),
                ),
                child: const Text('Salvar', style:TextStyle(color:Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
